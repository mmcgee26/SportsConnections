var express = require('express');
var session = require('cookie-session');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var crypto = require('crypto');
const {check, validationResult} = require('express-validator/check');

var app = express();
mongoose.connect('mongodb://localhost/project', {useNewUrlParser: true});

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

var Schema = mongoose.Schema;
var userConnectionSchema = new Schema({
    _uid: String,
    title: String,
    category: String,
    date: String,
    time: String,
    location: String,
    rsvp: Boolean
});
var ConnectionSchema = new Schema({
    _id: String,
    title: String,
    category: String,
    description: String,
    date: String,
    time: String,
    location: String
});
var UserSchema = new Schema({ //mongoose schemas
    _id: Number,
    passHash: String,
    salt: String,
    userName: String,
    firstName: String,
    lastName: String
});


var UserConnection = mongoose.model('UserConnection', userConnectionSchema); //mongoose models
var Connection = mongoose.model('Connection', ConnectionSchema);
var User = mongoose.model('User', UserSchema);
var isLogIn = false; //keeps track of if the user is sign in or not signed in
var UiD = null; //keeps track of what user is signed in currently

//this function makes the salts
var genRandom = function (length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex')
        .slice(0, length);
};
//this function hashes the password with the salt
var hashmaker = function (password, salt) {
    var hash = crypto.createHmac('sha512', salt);

    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt: salt,
        passwordHash: value
    };
};



(function getConnections(){ //get connections
   var events = [];
    Connection.find({}, function (err, docs) {
        events = docs;
    });
    return events;
})();


function getConnection(ID){ //get individual connection
    var data = [];
    Connection.find({_id: ID}, function (err, docs) {
        data = docs;
    });
    return data;
};

//start business logic

app.use(session({secret: 'uncc'})); //initialize session

app.get('/signin', function(req, res){ //singin handler
    //req.session.userInfo = UserDB[0];
    res.redirect('/savedConnections');
});
app.get('/signout', function(req, res){ //singout handler
    isLogIn = false;
    UiD = null;
    req.session = null;
    res.redirect('/');
});

app.get('/login', function(req, res){ //singout handler
    req.session = null;
    res.render('login');
});

//renders the error login page
app.get('/errorlogin', function (req, res) {
    res.render('errorlogin');
});

app.get('/register', function (req, res) {
    res.render('register');
});

app.get('/errorregister', function (req, res) {
    res.render('errorregister');
});

app.get('/', function(req, res){ //index handler
    res.render('index');
});

app.get('/connection/:ID', function(req, res){ //specific connection page by id handler
    Connection.find({_id: req.params.ID}, function (err, docs) {
        res.render('connection', {data: docs});
    });
});

app.get('/connection/title/:title', function(req, res){ //specific connection page by title handler
    Connection.find({title: req.params.title}, function (err, docs) {
        res.render('connection', {data: docs});
    });
});

app.get('/connections', function(req, res){ //connections page handler
    Connection.find({}, function (err, docs) {
        res.render('connections', {qs: req.query, data: docs}); //render connections page
    });
});

app.get('/savedConnections', function(req, res){ //saved connections page handler
    if (!(isLogIn)) { //checks to see if the user is logged in
        res.redirect('login')
    }
    else{
     UserConnection.find({_uid: UiD}, function (err, docs) { //find all user connections
        req.session.list = docs;
        
        res.render('savedConnections', {data: docs, qs: req.query}); //render saved connections
    
     });
    }
});

//This handles registration
app.post('/register', [
    //this validates the inputs
    check('user', 'Username is required.')
        .not().isEmpty()
        .isEmail()
        .normalizeEmail(),
    check('pass', 'Password is required.')
        .not().isEmpty()
        .isAlphanumeric()
        .trim()
        .escape(),
    check('first', 'First Name is required.')
        .not().isEmpty()
        .isAlpha(),
    check('lastn', 'Last Name is required.')
        .not().isEmpty()
        .isAlpha()
], function (req, res) {
    User.find({}, function (err, doc) {  //this finds all the users from the database
        var check = true;
        for (var i = 0; i < doc.length; i++) {
            if (doc[i].userName === req.body.user) { //this check to see if the username is unique
                check = false;
                break;
            }
        }
        if (check) {
            var salt = genRandom(16); //this makes the salt

            var passData = hashmaker(req.body.pass, salt); //this hashes the salt with the password
            //this saves the new user to the database
            var save = {
                _id: doc.length,
                passHash: passData.passwordHash,
                salt: passData.salt,
                userName: req.body.user,
                firstName: req.body.first,
                lastName: req.body.lastn
            };
            var data = new User(save);
            data.save();
        }
        if (!(check)) {
            res.redirect('errorregister')
        }
        if (check) {
            res.redirect('login')
        }
    });
});

app.post('/errorregister', [
     //this validates the inputs
     check('user', 'Username is required.')
     .not().isEmpty()
     .isEmail()
     .normalizeEmail(),
 check('pass', 'Password is required.')
     .not().isEmpty()
     .isAlphanumeric()
     .trim()
     .escape(),
 check('first', 'First Name is required.')
     .not().isEmpty()
     .isAlpha(),
 check('lastn', 'Last Name is required.')
     .not().isEmpty()
     .isAlpha()
], function (req, res) {
 User.find({}, function (err, doc) {  //this finds all the users from the database
     var check = true;
     for (var i = 0; i < doc.length; i++) {
         if (doc[i].userName === req.body.user) { //this check to see if the username is unique
             check = false;
             break;
         }
     }
     if (check) {
         var salt = genRandom(16); //this makes the salt

         var passData = hashmaker(req.body.pass, salt); //this hashes the salt with the password
         //this saves the new user to the database
         var save = {
             _id: doc.length,
             passHash: passData.passwordHash,
             salt: passData.salt,
             userName: req.body.user,
             firstName: req.body.first,
             lastName: req.body.lastn
         };
         var data = new User(save);
         data.save();
     }
     if (!(check)) {
         res.redirect('errorregister')
     }
     if (check) {
         res.redirect('login')
     }
    });
});

app.post('/login', [
    //this validates the inputs
    check('user')
        .isEmail()
        .normalizeEmail(),
    check('pass')
        .isAlphanumeric()
        .trim()
        .escape(),
], function (req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.redirect('errorlogin');
        return res.status(422).json({errors: errors.array()});
    }
    User.find({userName: req.body.user}, function (err, docs) { //this finds the user in the database
        let passData = hashmaker(req.body.pass, docs[0].salt); //this re-hashes the the password and the salt for comparison
        if (passData.passwordHash === docs[0].passHash) { //this compares the password hashes
            isLogIn = true;
            UiD = docs[0]._id;
            res.redirect('savedConnections');
        } else {
            res.redirect('errorlogin')
        }
    });
});

//this handles login
app.post('/errorlogin', [
    //this validates the inputs
    check('user')
        .isEmail()
        .normalizeEmail(),
    check('pass')
        .isAlphanumeric()
        .trim()
        .escape(),
], function (req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({errors: errors.array()});
    }
    User.find({userName: req.body.user}, function (err, docs) { //this finds the user in the database
        let passwordData = hashmaker(req.body.pass, docs[0].salt); //this re-hashes the the password and the salt
        if (passwordData.passwordHash === docs[0].passHash) { //this compares the password hashes
            isLogIn = true;
            UiD = docs[0]._id;
            res.redirect('savedConnections');
        } else {
            res.redirect('errorlogin')
        }
    });
});


app.get('/saveCon/:ID', function(req, res){
    UserConnection.find({_uid: UiD}, function (err, docs) { //find user connections

        Connection.find({}, function (err, doc) { //find connections

            var validation = true;
            for (var i = 0; i < docs.length; i++) {//loop through each

                if (docs[i].title === doc[req.params.ID].title) {

                    validation = false; 
                    break;
                }
            }
            
            if (validation) {
                var into = { //declare object going into db, fields come from params in form
                    _uid: UiD,
                    title: doc[req.params.ID].title,
                    category: doc[req.params.ID].category,
                    date: doc[req.params.ID].date,
                    time: doc[req.params.ID].time,
                    location: doc[req.params.ID].location,
                    rsvp: true,

                };
                var data = new UserConnection(into);
                data.save();
                
            }

        });
    });
    res.redirect('/savedConnections'); //redirect to saved connections to show update
});

app.get('/delete/:UID&:title', function(req, res){ //handler for deleting connection by id

    UserConnection.find({}, function (err, docs) {

        
            UserConnection.deleteOne({_uid: UiD, title: req.params.title}, function (err, pro) {
            });
        
        res.redirect('/savedConnections'); //redirect to saved connections to update on page
    });
});

app.get('/delete/title/:title', function(req, res){ //handler for deleting connection by title
    console.log(req.params.title);
    UserConnection.find({}, function (err, docs) {

        UserConnection.deleteOne({_uid: UiD, title: req.params.title}).exec(); //delete connection
    
        res.redirect('/savedConnections'); //redirect to saved connections to update on page
    });
});

app.post('/newCon', function(req, res){

    Connection.find({}, function (err, doc) { //find all connections

        var validation = true;
        for (var i = 0; i < doc.length; i++) { //loop through them

            if (doc[i].title === req.body.name) {

                validation = false; //failed for dupe check
                break;
            }
        }
        if (validation) {
            var into = { //declaring new connection to go into db, with each field from params on form
                _id: doc.length,
                title: req.body.name,
                category: req.body.topic,
                description: req.body.details,
                date: req.body.when,
                time: '2:00-5:00',
                location: req.body.where,

            };
            var data = new Connection(into); //put into db
            data.save(); //save
        }

    });

    res.redirect('/connections'); //redirect to connection page to show new connection
});

app.get('/about', function(req, res){ //rendering about page
    res.render('about');
});

app.get('/contact', function(req, res){ //rendering contact page
    res.render('contact');
});

app.get('/newConnection', function(req, res){ //rendering new connection page
    if(!isLogIn){
        res.redirect('/login');
    }
    else{
    res.render('newConnection');
    }
});

app.listen(3000); //open server