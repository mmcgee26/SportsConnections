var connection = {
    connectionID = 'C1',
    name = 'Panthers v Cardinals Watch Party',
    topic = 'Watch Party',
    details = 'Hello! Im hosting a watch party for the Carolina Panthers vs. Arizona Cardinals Game'+
    'Swing by with whatever snacks and/or drinks you would like to bring, and be ready to have fun!',
    date = '09/22/2019',
    time = '3:45-7:00'
}