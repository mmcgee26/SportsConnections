var express = require('express');
var session = require('cookie-session');
var bodyParser = require('body-parser');
var app = express();

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

//connections
var panthersparty = new Connection('C1','Panthers v Cardinals Watch Party','Football',
'Hello! Im hosting a watch party for the Carolina Panthers vs. Arizona Cardinals Game'+
'Swing by with whatever snacks and/or drinks you would like to bring, and be ready to have fun!',
'09/22/2019','3:45-7:00','YMCA');

var uncctailgate = new Connection('C2','UNCC Tailgate MeetUp','Football','UNCC Students meeting up to enjoy the tailgate together. Bring your own snacks!',
'10/19/2019','2:30-7:00','UNCC Tailgate Lot');

var flagfootball = new Connection('C3','Flag Football Saturdays','Football',
'Wanna play football? This is your place. Every Saturday, we play!','10/20/2019','12:00-3:00','UNCC Rec Fields');

var hornetsheatparty = new Connection('C4','Hornets v Heat Watch Party','Basketball',
'The Hornets take on the Heat! Come watch with us. Bring food!','11/25/2019','7:00-9:45','Belk Hall Lobby');

var hornetsknicksparty = new Connection('C5','Hornets v Knicks Watch Party','Basketball','The Hornets take on the Knicks! Come watch with us. Bring food!',
'11/16/2019','7:00-9:45','Belk Hall Lobby');

var pickupgames = new Connection('C6', 'Pick-Up Games','Basketball','Wanna play Basketball? Come on out, we play every Friday night',
'11/18/2019','6:00-9:00', 'Belk Gym');
//end connections

function Connection(id, title, category, details, date, time, location){
    this.id = id;
    this.title = title;
    this.category = category;
    this.details = details;
    this.date = date;
    this.time = time;
    this.location = location;
}

function User(userID, firstName, lastName, email){
    this.userID = userID;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
}

function UserConnection(connection, rsvp){
    this.connection = connection;
    this.rsvp = rsvp;
}

function UserProfile(UserID, List) {
    this.UserID = UserID;
    this.List = List;

    this.addConnection = function (connection, rsvp) {
        var dupe = false;
        for (let i = 0; i < List.length; i++) {
            if (List[i].connection == connection) {
                dupe = true;
            }
        }
        if (dupe == false) {
            var con = new UserConnection(connection, rsvp);
            List.push(con);
        }
    };
    this.updateConnection = function(connection, rsvp){
        for (let i = 0; i < List.length; i++) {
            if (List[i].connection == connection) {
                List[i].rsvp = rsvp;
            }
        }
    };
    this.removeConnection = function (connection) {
        for (let i = 0; i < List.length; i++) {
            if (List[i].connection === connection) {
                List.splice(i, 1);
            }
        }
    };

    this.getConnections = function () {
        return List;
    };
    this.emptyProfile = function () {
        this.UserID = "";
        this.List = "";
    }

}

var Michael = new User('0', 'Michael', 'McGee', 'mmcgee26@uncc.edu');
var Connor = new User('1', 'Connor', 'Vail', 'cvail2@uncc.edu');

var UserDB = [Michael, Connor];

var userconnection1 = new UserConnection(uncctailgate, 'Yes');
var userconnection2 = new UserConnection(flagfootball, 'Yes');

var connectionlist = [userconnection1, userconnection2];

var MichaelM = new UserProfile('0', connectionlist);
var UserProfileDB = [MichaelM];

function getUsers(){
    return UserDB;
}
function getUserProfiles(){
    return UserProfileDB;
}

var events = [];

(function getConnections(){
    events = [];
    events.push(panthersparty, uncctailgate, flagfootball, hornetsheatparty, hornetsknicksparty, pickupgames);
    return events;
})();

function getConnection(ID){
    var data = events.find(event => event.id === ID);
    //console.log(data);
    return data;
};

//start business logic

app.use(session({secret: 'uncc'}));

app.get('/signin', function(req, res){
    req.session.userInfo = UserDB[0];
    res.redirect('/savedConnections');
});
app.get('/signout', function(req, res){
    req.session = null;
    res.redirect('/');
});

app.get('/', function(req, res){
    res.render('index');
});

app.get('/connection/:ID', function(req, res){
    var data = getConnection(req.params.ID);
    if(!data){
        res.render('connection404');
    }
    else{
    res.render('connection', {data});
    }
});

app.get('/connections', function(req, res){
    res.render('connections');
});

app.get('/savedConnections', function(req, res){
    req.session.list = connectionlist;
    res.render('savedConnections', {req: req, qs: req.query});
});

app.get('/saveCon/:ID', function(req, res){
    var data = getConnection(req.params.ID);
    for (var i = 0; i < connectionlist.length; i++) {
        if (data !== connectionlist[i].connection) {
            UserProfileDB[0].addConnection(data, 'Yes');
            req.session.list = UserProfileDB[0].getConnections();
            res.redirect('/savedConnections');
        }
    }
});

app.get('/delete/:ID', function(req, res){
    UserProfileDB[0].removeConnection(connectionlist[req.params.ID].connection);
    res.redirect('/savedConnections');
});

app.get('/about', function(req, res){
    res.render('about');
});

app.get('/contact', function(req, res){
    res.render('contact');
});

app.get('/newConnection', function(req, res){
    res.render('newConnection');
});

app.listen(3000);