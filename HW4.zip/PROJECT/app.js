var express = require('express');
var session = require('cookie-session');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var app = express();
mongoose.connect('mongodb://localhost/project', {useNewUrlParser: true});

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

var Schema = mongoose.Schema;
var userConnectionSchema = new Schema({
    _uid: String,
    _id: String,
    title: String,
    category: String,
    date: String,
    time: String,
    location: String,
    rsvp: Boolean
});
var ConnectionSchema = new Schema({
    _id: String,
    title: String,
    category: String,
    description: String,
    date: String,
    time: String,
    location: String
});
var UserSchema = new Schema({ //mongoose schemas
    _id: String,
    username: String,
    password: String,
    firstName: String,
    lastName: String,
});


var UserConnection = mongoose.model('UserConnection', userConnectionSchema); //mongoose models
var Connection = mongoose.model('Connection', ConnectionSchema);
var User = mongoose.model('User', UserSchema);


function getUsers(){
    return UserDB;
}
function getUserProfiles(){
    return UserProfileDB;
}

var events = [];

(function getConnections(){ //get connections
   var events = [];
    Connection.find({}, function (err, docs) {
        events = docs;
    });
    return events;
})();


function getConnection(ID){ //get individual connection
    var data = [];
    Connection.find({_id: ID}, function (err, docs) {
        data = docs;
    });
    return data;
};

//start business logic

app.use(session({secret: 'uncc'})); //initialize session

app.get('/signin', function(req, res){ //singin handler
    //req.session.userInfo = UserDB[0];
    res.redirect('/savedConnections');
});
app.get('/signout', function(req, res){ //singout handler
    req.session = null;
    res.redirect('/');
});

app.get('/', function(req, res){ //index handler
    res.render('index');
});

app.get('/connection/:ID', function(req, res){ //specific connection page by id handler
    Connection.find({_id: req.params.ID}, function (err, docs) {
        res.render('connection', {data: docs});
    });
});

app.get('/connection/title/:title', function(req, res){ //specific connection page by title handler
    Connection.find({title: req.params.title}, function (err, docs) {
        res.render('connection', {data: docs});
    });
});

app.get('/connections', function(req, res){ //connections page handler
    Connection.find({}, function (err, docs) {
        res.render('connections', {qs: req.query, data: docs}); //render connections page
    });
});

app.get('/savedConnections', function(req, res){ //saved connections page handler
    
    UserConnection.find({}, function (err, docs) { //find all user connections
        req.session.list = docs;
        
        res.render('savedConnections', {data: docs, qs: req.query}); //render saved connections

    });
});
var p = 2;  //used for id later
app.get('/saveCon/:ID', function(req, res){
    UserConnection.find({}, function (err, docs) { //find user connections

        Connection.find({}, function (err, doc) { //find connections

            var validation = true;
            for (var i = 0; i < docs.length; i++) {//loop through each

                if (docs[i].title === doc[req.params.ID].title) {

                    validation = false; 
                    break;
                }
            }
            
            if (validation) {
                var into = { //declare object going into db, fields come from params in form
                    _uid: "0",
                    _id: p,
                    title: doc[req.params.ID].title,
                    category: doc[req.params.ID].category,
                    date: doc[req.params.ID].date,
                    time: doc[req.params.ID].time,
                    location: doc[req.params.ID].location,
                    rsvp: true,

                };
                var data = new UserConnection(into);
                data.save();
                p++;
            }

        });
    });
    res.redirect('/savedConnections'); //redirect to saved connections to show update
});

app.get('/delete/:ID', function(req, res){ //handler for deleting connection by id
    console.log(req.params.ID);
    UserConnection.find({}, function (err, docs) {

        UserConnection.findByIdAndDelete(req.params.ID).exec(); //delete connection
        if (docs.length === 1) {
            console.log("Last Saved Connection Deleted");
            UserConnection.deleteOne({}, function (err, pro) {
            });
        }
        res.redirect('/savedConnections'); //redirect to saved connections to update on page
    });
});

app.get('/delete/title/:title', function(req, res){ //handler for deleting connection by title
    console.log(req.params.title);
    UserConnection.find({}, function (err, docs) {

        UserConnection.deleteOne({title: req.params.title}).exec(); //delete connection
    
        res.redirect('/savedConnections'); //redirect to saved connections to update on page
    });
});

app.post('/newCon', function(req, res){

    Connection.find({}, function (err, doc) { //find all connections

        var validation = true;
        for (var i = 0; i < doc.length; i++) { //loop through them

            if (doc[i].title === req.body.name) {

                validation = false; //failed for dupe check
                break;
            }
        }
        if (validation) {
            var into = { //declaring new connection to go into db, with each field from params on form
                _id: doc.length,
                title: req.body.name,
                category: req.body.topic,
                description: req.body.details,
                date: req.body.when,
                time: '2:00-5:00',
                location: req.body.where,

            };
            var data = new Connection(into); //put into db
            data.save(); //save
        }

    });

    res.redirect('/connections'); //redirect to connection page to show new connection
});

app.get('/about', function(req, res){ //rendering about page
    res.render('about');
});

app.get('/contact', function(req, res){ //rendering contact page
    res.render('contact');
});

app.get('/newConnection', function(req, res){ //rendering new connection page
    res.render('newConnection');
});

app.listen(3000); //open server